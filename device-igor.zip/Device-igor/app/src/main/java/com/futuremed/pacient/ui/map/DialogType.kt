package com.futuremed.pacient.ui.map

import android.content.Context
import com.futuremed.pacient.R
import com.google.android.material.bottomsheet.BottomSheetDialog

enum class DialogType {
    HOSPITAL,
    AMBULANCE,
    PHARMACY
}
package com.futuremed.pacient.data.model

enum class UserGender {
    MAN,
    WOMAN,
    NONE
}